import React from 'react';
export declare const ConnectedSitesScreen: React.FC;
