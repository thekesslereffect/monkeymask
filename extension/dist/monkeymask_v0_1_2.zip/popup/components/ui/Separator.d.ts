export declare const Separator: ({ className }: {
    className: string;
}) => import("react/jsx-runtime").JSX.Element;
