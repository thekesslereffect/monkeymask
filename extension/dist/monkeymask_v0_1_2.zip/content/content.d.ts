declare const script: HTMLScriptElement;
