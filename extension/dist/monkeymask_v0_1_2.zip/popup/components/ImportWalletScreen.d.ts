import React from 'react';
interface ImportWalletScreenProps {
    onWalletImported: () => void;
    onBack: () => void;
}
export declare const ImportWalletScreen: React.FC<ImportWalletScreenProps>;
export {};
