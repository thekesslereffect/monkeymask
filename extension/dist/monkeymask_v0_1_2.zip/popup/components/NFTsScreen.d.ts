import React from 'react';
export declare const NFTsScreen: React.FC;
