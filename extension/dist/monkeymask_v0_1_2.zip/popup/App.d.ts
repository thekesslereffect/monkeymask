import React from 'react';
import './styles.css';
export declare const App: React.FC;
