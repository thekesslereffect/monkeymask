import React from 'react';
export declare const DashboardScreen: React.FC;
