import React from 'react';
interface ContentContainerProps {
    children: React.ReactNode;
    className?: string;
}
export declare const ContentContainer: React.FC<ContentContainerProps>;
export {};
