import React from 'react';
interface CreateWalletScreenProps {
    onWalletCreated: () => void;
    onBack: () => void;
}
export declare const CreateWalletScreen: React.FC<CreateWalletScreenProps>;
export {};
