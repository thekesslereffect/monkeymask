import React from 'react';
export declare const SettingsScreen: React.FC;
