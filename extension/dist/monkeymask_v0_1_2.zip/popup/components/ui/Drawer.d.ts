import React from 'react';
interface DrawerProps {
    className?: string;
}
export declare const Drawer: React.FC<DrawerProps>;
export {};
