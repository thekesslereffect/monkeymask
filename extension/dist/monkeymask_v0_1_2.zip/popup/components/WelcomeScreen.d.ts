import React from 'react';
interface WelcomeScreenProps {
    onCreateWallet: () => void;
    onImportWallet: () => void;
}
export declare const WelcomeScreen: React.FC<WelcomeScreenProps>;
export {};
