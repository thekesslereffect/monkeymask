import React from 'react';
export declare const ExploreScreen: React.FC;
