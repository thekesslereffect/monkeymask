import React from 'react';
interface FooterProps {
    active?: boolean;
    className?: string;
}
export declare const Footer: React.FC<FooterProps>;
export {};
