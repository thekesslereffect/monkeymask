export declare const PageName: ({ name, back }: {
    name: string;
    back?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
