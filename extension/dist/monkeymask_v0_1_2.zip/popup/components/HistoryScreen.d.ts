import React from 'react';
export declare const HistoryScreen: React.FC;
