import React from 'react';
interface HeaderProps {
    active?: boolean;
}
export declare const Header: React.FC<HeaderProps>;
export {};
