import React from 'react';
export declare const ThemeToggle: React.FC;
